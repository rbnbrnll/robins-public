# -*- coding: utf-8 -*-
"""
Created on Mon Nov 14 11:43:09 2016

@author: Robin
"""

import sys
import pickle
from create_new_feat import new_feat #adds pct_sent and pct_rcvd features
sys.path.append("../tools/")
from sklearn.cross_validation import StratifiedShuffleSplit
from feature_format import featureFormat, targetFeatureSplit
from sklearn.feature_selection import SelectKBest
import numpy as np
import pprint as pp
from sklearn.preprocessing import MinMaxScaler

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".

#Specify all features for KBest

features_list = ['poi', 
 'to_messages',
 'deferral_payments',
 'pct_sent',
 'expenses',
 'deferred_income',
 'long_term_incentive',
 'restricted_stock_deferred',
 'shared_receipt_with_poi',
 'loan_advances',
 'from_messages',
 'other',
 'director_fees',
 'bonus',   # position **** 13
 'total_stock_value',
 'from_poi_to_this_person',
 'from_this_person_to_poi',
 'restricted_stock',
 'pct_rcvd',
 'salary',
 'total_payments',
 'exercised_stock_options']

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

### Task 2: Remove outliers
#Remove the Total line item and data for the travel agency
data_dict.pop("TOTAL", 0)
data_dict.pop("THE TRAVEL AGENCY IN THE PARK", 0)
### Task 3: Create new feature(s) by invoking the function in create_new_feat 
data_dict = new_feat(data_dict)
### Store to my_dataset for easy export below.
my_dataset = data_dict

features_scores = {}
folds = 1000

### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)
cv = StratifiedShuffleSplit(labels, folds, random_state = 42)

scaler = MinMaxScaler()
features = scaler.fit_transform(features)
#print "features", features[0:5]
#print "features_scaled", features_scaled[0:5]  


### split and generate indices for training and testing sets
for i_train, i_test in cv:
    features_train, features_test = [features[i] for i in i_train], [features[i] for i in i_test]
    labels_train, labels_test = [labels[i] for i in i_train], [labels[i] for i in i_test]

    ### fit the selector on the training set
    selector = SelectKBest(k="all")
    
    selector = selector.fit(features_train, labels_train)
    
    ### Get the scores of each feature by using get_support to retrieve the 
    ### index of the selected features 
    sel_features = np.array(features_list[1:])[selector.get_support()]
    sel_list = []
    for i in range(len(sel_features)):
        sel_list.append([sel_features[i], selector.scores_[i], selector.pvalues_[i]])
    
    #### fil the feature_scores dictionary
    for feat, score, pvalue in sel_list:
        if feat not in features_scores:
            features_scores[feat] = {'scores': [], 'pvalues':[]}
        features_scores[feat]['scores'].append(score)
        features_scores[feat]['pvalues'].append(pvalue)
        
        
### Average the scores and pvalues of each feature
features_scores_l = []  ### tuple of feature name, average scores, average pvalues
for feat in features_scores:
    features_scores_l.append((feat, np.mean(features_scores[feat]['scores']), np.mean(features_scores[feat]['pvalues'])))
####Robin added the following lines

### sort scores so highest is first and then display them
### itemgetter retrieves the mean scores value
import operator
sorted_feature_scores = sorted(features_scores_l, key=operator.itemgetter(1), reverse=True)
sorted_feature_scores_str =["{}, {}, {}".format(x[0], x[1], x[2]) for x in sorted_feature_scores]
                            
print "feature, score, pvalue"
pp.pprint(sorted_feature_scores_str)

""" Robin now that we have what KBest thinks - let's comment it out #Let's see what KBest thinks

from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
rescale_train = scaler.fit_transform(features_train)

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif

clf = SelectKBest(f_classif, k = 5)
#clf.fit_transform(features_train, labels_train)
clf.fit_transform(rescale_train, labels_train)
pos = 0
print clf.scores_
print "for easier reading:"
for score in clf.scores_:
    pos +=1
    print "position", pos, "has", int(score)

"""