# -*- coding: utf-8 -*-
"""
Created on Mon Nov 14 12:55:33 2016

@author: Robin
"""
def split_alg(labels, features, tuning_mode):
    """find the optimal values for number of neighbors and leaves"""
    folds = 1000
    from sklearn import grid_search
    
    from sklearn.cross_validation import StratifiedShuffleSplit
    from sklearn.neighbors import KNeighborsClassifier
   
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.pipeline import Pipeline
    from time import time
    cv = StratifiedShuffleSplit(labels, folds, random_state = 42)
    for train_idx, test_idx in cv: 
        features_train = []
        features_test  = []
        labels_train   = []
        labels_test    = []
        for ii in train_idx:
            features_train.append( features[ii] )
            labels_train.append( labels[ii] )
        for jj in test_idx:
            features_test.append( features[jj] )
            labels_test.append( labels[jj] )
    if tuning_mode == True:
        parameters = [{"classifier__n_neighbors": list(range(1,11)), "classifier__leaf_size": list(range(1,41))}]

        kneigh = KNeighborsClassifier(weights = 'distance', p = 2, algorithm = 'brute')
    #per this post in the forum, removing looping
    #https://discussions.udacity.com/t/gridsearchcv-and-kfold-validation/32459/12
    
        pipe_steps = [('scaler', MinMaxScaler()), ('classifier', kneigh)]
        pipe = Pipeline(pipe_steps)
   
        print "time before gridsearch", time()
        grid = grid_search.GridSearchCV(pipe, parameters, cv = cv, scoring = "f1")
    
        print "time after gridsearch", time()
   
        grid.fit(features, labels)
        print "time after fit", time()
        # save the best parameters
        neigh_sav = grid.best_params_["classifier__n_neighbors"] 
        leaf_sav =  grid.best_params_["classifier__leaf_size"]    
        print "f1 after fit", grid.best_score_, grid.best_params_
    else:
        neigh_sav = 0
        leaf_sav = 0
    return(features_train, features_test, labels_train, labels_test, neigh_sav, leaf_sav) 

###########################################################
    
    
def tune_alg(rescale_train, labels_train, features_test, my_dataset, features_list):
    """find the optimal values for number of neighbors and leaves
       this was a first attempt and required a modification to the tester.py
       function.  At this time it is not used in any processing
       but has been kept in case additional processing is required 
       after project review"""
##found the n=6 and leaf size = 1. with salary, exercised stock, bonus
    from sklearn.neighbors import KNeighborsClassifier
    from tester import test_classifier
    f_max = 0 #for saving the highest max score
    for neigh in range(1,15):  
        for leaf in range(1,40):
            clf = KNeighborsClassifier(n_neighbors = neigh, algorithm = 'brute', leaf_size = leaf, p=2, weights = 'distance') # p = .64, r=.26, f1=.37
### Task 5: Tune your classifier to achieve better than .3 precision and recall 
### using our testing script. Check the tester.py script in the final project
### folder for details on the evaluation method, especially the test_classifier
### function. Because of the small size of the dataset, the script uses
### stratified shuffle split cross validation. For more info: 
### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html
 

            clf = clf.fit(rescale_train, labels_train)
                                           
            a, p, r, f = test_classifier(clf, my_dataset, features_list) 

            if f > f_max:
                f_max = f
                p_sav = p
                r_sav = r
                neigh_sav = neigh
                leaf_sav = leaf
    print "***** f, p, r, neigh, leaf", f_max, p_sav, r_sav, neigh_sav, leaf_sav           
    return (neigh_sav, leaf_sav)
    

