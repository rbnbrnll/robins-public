#!/usr/bin/python

import sys
import pickle
from create_new_feat import new_feat
sys.path.append("../tools/")

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".

features_list = ['poi', 'exercised_stock_options', 'total_stock_value', 'bonus']

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

### Task 2: Remove outliers
#Remove the Total line item and data for the travel agency
data_dict.pop("TOTAL", 0)
data_dict.pop("THE TRAVEL AGENCY IN THE PARK", 0)
### Task 3: Create new feature(s)
data_dict = new_feat(data_dict)
### Store to my_dataset for easy export below.
my_dataset = data_dict

### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)

### Task 4: Try a varity of classifiers
### Please name your classifier clf for easy export below.
### Note that if you want to do PCA or other multi-stage operations,
### you'll need to use Pipelines. For more info:
### http://scikit-learn.org/stable/modules/pipeline.html

# Provided to give you a starting point. Try a variety of classifiers.

#from sklearn.naive_bayes import GaussianNB
#clf = GaussianNB()   #got Prec=.46 and recall .31 and f1 .377

#from sklearn.svm import SVC
#clf = SVC(kernel = "rbf", C = 100000)   # decimal error


#features_train, features_test, labels_train, labels_test = train_test_split(features, labels, test_size=0.3, random_state=42)


### Call the function to find the best number of neighbors and leafs
tuning_mode = False #set this to true to help determine best parameters

from split_alg import split_alg
features_train, features_test, labels_train, labels_test, nbrs, lf = split_alg(labels, features, tuning_mode)
if nbrs == 0:
    lf = 1     ### these were values set by the tune_alg during test phase
    nbrs = 4   ### set to speed up processing

# now perform the classifier using the best number of neighbors
# and the best number of leaves with scaling
from sklearn.neighbors import KNeighborsClassifier
k_clf = KNeighborsClassifier(n_neighbors = nbrs, algorithm = 'brute', leaf_size = lf, p=2, weights = 'distance')  #robin changed to uniform

#invoke scaling since using K nearestneighbor Classifier
from sklearn.preprocessing import MinMaxScaler

steps = [('scaler', MinMaxScaler()), ('classifier', k_clf)]

from sklearn.pipeline import Pipeline
clf = Pipeline(steps)
clf = clf.fit(features_train, labels_train)

### Task 6: Dump your classifier, dataset, and features_list so anyone can
### check your results. You do not need to change anything below, but make sure
### that the version of poi_id.py that you submit can be run on its own and
### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, features_list)  