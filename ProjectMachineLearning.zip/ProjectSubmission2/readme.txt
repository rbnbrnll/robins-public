Description of extra files

findthebest.py - This is a standalone function used in the initial analysis phase to determine best features.  Uses KBest.

  
create_new_feat.py - computes and adds pct_rcvd and pct_sent features.  Called from poi_id.py

split_alg.py - creates training and testing datasets using StratifiedShuffle split and if desired finds the best parameters for KNeighborsClassifer.  Function split_alg is in here and is called from poi_id.py
