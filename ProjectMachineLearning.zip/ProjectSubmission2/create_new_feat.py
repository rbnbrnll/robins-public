# -*- coding: utf-8 -*-
"""
Created on Thu Nov 03 14:57:44 2016

@author: Robin
"""

def new_feat(in_dict):
    """calculate percents for sent and received messages"""

    for e in in_dict:
#  if we don't have any two messages skip this part
        pct_rcvd = 0
        pct_sent = 0
        if in_dict[e]["to_messages"] not in ["NaN", 0]:
        
#  save the data for easier reading of calculation
            to_msgs = in_dict[e]["to_messages"] * 1.
#            shrd_rcpt = in_dict[e]["shared_receipt_with_poi"]
            from_poi = in_dict[e]["from_poi_to_this_person"] 
            pct_rcvd = (from_poi/to_msgs)
#  Set the value in the dictionary
            in_dict[e]["pct_rcvd"] = pct_rcvd
        else:
            in_dict[e]["pct_rcvd"] = 0
   
#  If we don't have any "from messages" skip this part

        if in_dict[e]["from_messages"] not in ["NaN", 0]:
        
#  save the data for easier reading of calc.
            from_msgs = in_dict[e]["from_messages"] * 1.
            sent_to_poi = in_dict[e]["from_this_person_to_poi"]
            pct_sent = sent_to_poi / from_msgs
#  Set the value in the dictionary
            in_dict[e]["pct_sent"] = pct_sent
        else:
            in_dict[e]["pct_sent"] = 0 
    return in_dict    