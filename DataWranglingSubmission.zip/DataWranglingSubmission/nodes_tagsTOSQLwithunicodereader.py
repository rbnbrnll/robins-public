# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 09:47:50 2016

@author: Robin
"""
import sqlite3

import csv
CSVFILE = "nodes_tags.csv"

def UnicodeDictReader(utf8_data, **kwargs):
    """Handle Unicode data"""
    
    csv_reader = csv.DictReader(utf8_data, **kwargs)
    for row in csv_reader:
        yield {key: unicode(value, 'utf-8') for key, value in row.iteritems()}
        
with open (CSVFILE, 'rb') as csvfile:
    csv_reader = UnicodeDictReader(csvfile)
    I_QUERY = "INSERT INTO nodes_tags (id, key, value, type) VALUES (:id, :key, :value, :type);"
    with sqlite3.connect("new_montreal") as db:
        c = db.cursor()
        c.executemany(I_QUERY, csv_reader)
        db.commit()
        
        # Now print the data here
        c.execute("""SELECT * FROM nodes_tags where id = '300159724';""")
        all_rows = c.fetchall()
        print('1):')
        for r in all_rows:
            print r[2]
