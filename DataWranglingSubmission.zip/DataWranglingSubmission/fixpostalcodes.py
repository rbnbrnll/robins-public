# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 09:47:50 2016

@author: Robin
"""

import re
import sqlite3

"""Correct postcodes for the Montreal and surrounding areas should start 
with an H or J, the 2nd character should be a  digit, the third an uppercase
or alphanumeric, the 4th a single space and the last 3 characters any 
UPPERCASE alphanumeric """

CORRECT_POST = re.compile(r'[H|J][0-9]{1}[A-Z]{1}\s[A-Z0-9]{3}')

NS_QUERY =  ("""SELECT id, value FROM nodes_tags WHERE key="postcode"; """)
NU_QUERY = ("""UPDATE nodes_tags SET value = ? WHERE id = ? and key = "postcode"; """)  

WS_QUERY =  ("""SELECT id, value FROM ways_tags WHERE key="postcode"; """)
WU_QUERY = ("""UPDATE ways_tags SET value = ? WHERE id = ? and key = "postcode"; """)  

DB = sqlite3.connect("new_montreal") 

def fix_post(p):
    """Attempt to fix the post code"""
    
    save_post = p                      #save the code in case we can't fix it
   
    p = p.upper()                      #No matter what capitalize the the code
    
    qc_pos = p.find("QC")              #remove QC if in postcode
    if qc_pos == 0:
        p = p[2:]       
        p = p.lstrip()                 #remove leading blanks
        
    dash_pos = p.find("-")             #remove dashes
    if dash_pos != -1:
        p = p[0:dash_pos] + p[dash_pos+1:]
        
    if len(p) == 6:                    #add a space if we have only 6 chararcters
        p = p[0:3] + " " + p[3:]

    if CORRECT_POST.search(p):
        return p
    else:
        print "couldn't fix", save_post
        return save_post        

def update_db(c, r_id, p, f_type):
    """update the correct file with the new postal code"""

    if f_type == "nodes":
        print "fixing node", r_id
        c.execute(NU_QUERY, (p, r_id,))
    else:
        print "fixing ways", r_id
        c.execute(WU_QUERY, (p, r_id))
    
def process_rows(c, f_type):
    """process each row in what ever file working with"""
    
    all_rows = c.fetchall()
    for r in all_rows:
        r_id = r[0]
        post_code = r[1]
        if not CORRECT_POST.search(post_code):
            post_code = fix_post(post_code)
            update_db(c, r_id, post_code, f_type)


c = DB.cursor()
               
#Select the postcode records from both files and process them


c.execute(NS_QUERY)

process_rows(c, "nodes")

c.execute(WS_QUERY)
process_rows(c, "ways")
DB.commit()
DB.close()