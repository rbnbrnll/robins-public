# -*- coding: utf-8 -*-
"""
Created on Sat Jul 16 09:29:57 2016

@author: Robin
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml.etree.cElementTree as ET
import pprint
import codecs
import csv
import collections
import operator
"""
Your task is to explore the data a bit more.
The first task is a fun one - find out how many unique users
have contributed to the map in this particular area!

The function process_map should return a set of unique user IDs ("uid")
"""
USER_FIELDS = ("user", "num_posts")

def rank_users(users):
    """The following sorted function takes in as the first parm
    the tuples resulting from users.items() and then sorts them by the 
    2nd value in the tuple(i.e. position 1) which is the count of times
    a given user contributed"""
    
    sorted_users = sorted(users.items(), key=operator.itemgetter(1), reverse=True)
    print "sorted users", sorted_users
    return sorted_users


def process_map(filename):
    """Evaluate all elements in the file to find the users"""
    
    users = collections.defaultdict(int)
    
    for _, element in ET.iterparse(filename):
        if 'user' in element.attrib:
            #print "uid", element.attrib['uid']
            
            users[element.attrib['user']] +=1
        pass

    return users

class UnicodeDictWriter(csv.DictWriter, object):
    """Extend csv.DictWriter to handle Unicode input"""

    def writerow(self, row):
        super(UnicodeDictWriter, self).writerow({
            k: (v.encode('utf-8') if isinstance(v, unicode) else v) for k, v in row.iteritems()
        })

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)

def write_to_file(users):
    """Write the users to a file"""
    
    with codecs.open("users.csv", "w") as u_file:
        u_writer = UnicodeDictWriter(u_file, USER_FIELDS)
        u_writer.writeheader()
        num_users = 0
        for u in users:
            to_write = [{"user":u, "num_posts": users[u]}]
            #print "u here", to_write
            num_users += 1
            u_writer.writerows(to_write)    
            print "total number of unique users:", num_users
      

if __name__ == "__main__":
    
    users = process_map('montreal_map.osm')
    top_users = rank_users(users) 
    write_to_file(users)
    pprint.pprint(top_users)