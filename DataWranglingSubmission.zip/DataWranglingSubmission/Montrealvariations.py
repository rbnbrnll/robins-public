# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 09:47:50 2016

@author: Robin
"""
import sqlite3


db = sqlite3.connect("new_montreal") 
c = db.cursor()
               
   # Now print the data here
c.execute("""SELECT c.value, count(*) AS count FROM (SELECT value FROM nodes_tags WHERE key="city" and value like "%Mont%" UNION ALL SELECT value FROM ways_tags WHERE key="city" and value like "%Mont%") c GROUP BY c.value ORDER BY count DESC LIMIT 10;""")
all_rows = c.fetchall()
print('1):')
for r in all_rows:
    print r[0], r[1]
