# -*- coding: utf-8 -*-
"""
Created on Fri Jul 22 09:05:14 2016

@author: Robin
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml.etree.cElementTree as ET


"""
Here we are actually trying to find the exact problem element and 
associated tags.
"""


PROBLEM_VALUES = ['addr.source:street', 'addr.source:housenumber', 'Rendu 3D', 'service road']

OUTFILE = open("bad_keys.txt", "w")

FILE_IN = "montreal_map.osm"


def key_type(element):
    """This routine is just checking if the key('k' attribute) is correct """
    
    
    if element.tag == "node" or element.tag == "way" :
    #save the tags parent in case we encounter a problem with a tag
        
        parent_tag = element.tag       
        parent_items = element.items()
        parent_keys = element.keys()        
        for tag in element.iter("tag"):
            element_value = tag.attrib['k']
        
            if element_value in PROBLEM_VALUES:
            
                OUTFILE.write("parent tag " + parent_tag)
                OUTFILE.write("parent items " + str(parent_items))    
                OUTFILE.write("parent keys " + str(parent_keys))
                OUTFILE.write("bad data " + ET.tostring(tag))            
            
    return


def get_element(osm_file, tags=('node', 'way', 'relation')):
    """Yield element if it is the right type of tag"""

    context = ET.iterparse(osm_file, events=('start', 'end'))
    _, root = next(context)
    for event, elem in context:
        if event == 'end' and elem.tag in tags:
            yield elem
            root.clear()

def process_map(filename):
    """ Check each in the file to see if contains the found problems """

    for element in get_element(FILE_IN):
        key_type(element)
 
def test():
   
    process_map(FILE_IN)
   


if __name__ == "__main__":
    test()
    OUTFILE.close()    
    