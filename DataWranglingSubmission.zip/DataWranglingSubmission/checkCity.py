# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 09:35:39 2016

@author: Robin


- check City names and create a file containing city name and number of times it 
occurred
"""
import xml.etree.cElementTree as ET
import collections
import codecs
import csv


OSM_FILE = "montreal_map.osm "
OUT_FILE = "cities.csv"

CITY_FIELDS =("city", "count")


def audit_city(city_name, cities):
    """Keep track of the number of times the city name occurred"""
       
    cities[city_name] += 1
  
        
def is_city_name(elem):
    """Check if we are dealing with a city tag"""
    
    return (elem.attrib['k'] == "addr:city")


def audit(osmfile, cities):
    """Process each element in the incoming file"""
    
    osm_file = open(osmfile, "r")
    
    for event, elem in ET.iterparse(osm_file, events=("start",)):

        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_city_name(tag):
                    audit_city(tag.attrib['v'], cities)
    osm_file.close()
    return 

class UnicodeDictWriter(csv.DictWriter, object):
    """Extend csv.DictWriter to handle Unicode input"""

    def writerow(self, row):
        super(UnicodeDictWriter, self).writerow({
            k: (v.encode('utf-8') if isinstance(v, unicode) else v) for k, v in row.iteritems()
        })

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)

def write_to_file(cities):
    """Add any cities found to a csv file for later editing"""
    
    with codecs.open(OUT_FILE, "w") as c_file:
        c_writer = UnicodeDictWriter(c_file, CITY_FIELDS)
        c_writer.writeheader()
       
        for c in cities:
            to_write = [{"city":c, "count": cities[c]}]
                   
            c_writer.writerows(to_write)    
    

if __name__ == '__main__':
    city_dict = collections.defaultdict(int)
    audit(OSM_FILE, city_dict)
    write_to_file(city_dict)    
