# -*- coding: utf-8 -*-
"""
Created on Tue Jul 26 13:49:09 2016

@author: Robin
This code edits the street name in the nodes_tags table and for each
street name fixed saves the original and corrected in a csv file
"""

import sqlite3
import codecs
import csv
import collections

STREET_FIELDS = ("original", "corrected", "count")


MAPPING = { "Ave.": "Avenue",
            "Blvd.": "Boulevard",
            "Blvd": "Boulevard",
            "blvd": "Boulevard",
            "Ave": "Avenue",
            "Rd.": "Road",  
                                  
            }
DIRECTION_MAP = {
            "N": "Nord",
            "S": "Sud",
            "E": "Est",
            "O": "Ouest",
            "N.": "Nord",
            "S.": "Sud",
            "E.": "Est",
            "O.": "Ouest",
            
            }
            
            
def update_street(name):
    """Fix the street name if a problem exists"""
    
    parts = name.split()
    changed = False
    #first check if the street contains an abbreviation or "Street" 
    for w in range(len(parts)):
        if parts[w] in MAPPING:
            parts[w] = MAPPING[parts[w]]
            changed = True
    #Check if the last part of the street name is an abbreviated direction
    last_pos = len(parts)-1
    if parts[last_pos] in DIRECTION_MAP:
       
        parts[last_pos] = DIRECTION_MAP[parts[last_pos]]
        changed = True
    if changed:
        name = " ".join(parts)
                          
    else:
        name = " "
    return name

class UnicodeDictWriter(csv.DictWriter, object):
    """Extend csv.DictWriter to handle Unicode input"""

    def writerow(self, row):
        super(UnicodeDictWriter, self).writerow({
            k: (v.encode('utf-8') if isinstance(v, unicode) else v) for k, v in row.iteritems()
        })

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)

def write_to_file(streets):
    """Keep track of the street names we have modified"""
    
    with codecs.open("corrected_streets.csv", "w") as s_file:
        s_writer = UnicodeDictWriter(s_file, STREET_FIELDS)
        s_writer.writeheader()
       
        for s in streets:
            to_write = [{"original":s[0], "corrected":s[1],  "count": streets[s]}]
                   
            s_writer.writerows(to_write)    


def add_to_dict(original, new, s_dict):
    """Keep track of how many times we find the same problem"""
    
    #either add the tuple to the database or update it's counter    
    s_dict[(original, new)] += 1
    return s_dict
    
    
    
 # Fetch records from montreal database  
    
street_dict = collections.defaultdict(int) #keys are tuples containing "original", "new"
db = sqlite3.connect("montreal")
c = db.cursor()
S_QUERY = 'SELECT * FROM nodes_tags WHERE key="street";'
c.execute(S_QUERY)
rows = c.fetchall()

for row in rows:
    street_name = row[2]
    
    fixed_street = update_street(street_name)
    #only if something in the street name was modified should we update the table  
    r_id = row[0]
   
    if fixed_street != " ":  
        print "fixed street", fixed_street
        #Fix the street in the data
        U_QUERY = 'UPDATE nodes_tags SET value = ? WHERE id = ? and key = "street";'
        c.execute(U_QUERY, (fixed_street, r_id,))
        #also add the change to a dictionary for writing to a file
        street_dict = add_to_dict(street_name, fixed_street, street_dict)
        print "street_dict", street_dict
        
db.commit()
db.close()
print "street dict", street_dict
write_to_file(street_dict)

